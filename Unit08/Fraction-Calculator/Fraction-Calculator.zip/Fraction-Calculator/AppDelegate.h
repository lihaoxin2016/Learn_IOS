//
//  AppDelegate.h
//  Fraction-Calculator
//
//  Created by 李昊鑫 on 16/3/30.
//  Copyright © 2016年 lhx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

